from random import choice
from random import randint


#---------------dessin en ASCII et interface du jeu------------------------->>>
dessins = ["""
        ______ éssais n°1

          """,
          """
          |
          |
          |
          |
     _____|éssais n°2
          """,
          """
     _____
          |
          |
          |
          |
     _____|éssais n°3
          """,
          """
     _____
     |    | 
          |
          |
          |
     _____|éssais n°4
          """,
          """
     _____
     |    | 
     o    |
          |
          |
     _____|éssais n°5
          """,
          """
     _____
     |    | 
     o    |
     |    |
          |
     _____|éssais n°6
          """,
          """
     _____
     |    |
     o    |
    /|    |
          |
     _____|éssais n°7
          """,
          """
    _____
    |    |
    o    |
   /|\   |
         |
    _____|éssais n°8
          """,
          """
    _____
    |    |
    o    |
   /|\   |
   /     |
    _____|éssais n°9
          """,
          """
     _____
     |    |
     o    |
    /|\   |
    / \   |
     _____|éssais n°10
          """]



#-------------------affectations des variables---------------------------->>>
nb = 6
monMot = []
nombre_essaie = 0
lettre_vrai = []
lettre_faux = []
fic = "dictionnaire.txt"
lettre = []


#------------------choix du mot dans la list (dictionnaire.txt)--------------------->>>
def choix_mot(fic):
    with open(fic, encoding="utf-8") as f:
        l = f.readline()
        line = randint(0,835)
        for a in range(line-1):
            p=f.readline()
        mot =  f.readline()
        return mot[0:-1]
    

#--------------------fonction affichage dessin-------------------------->>>
def show_pendu():
  num = len(lettre_faux)
  print(dessins[num -1])


#--------------------affiche le mot et la lettre vrai-------------------------->>>
def affiche_mot(mot, lettre_vrai):
  i = 0
  monMot = []
  while i < len(mot):
    if mot[i] in lettre_vrai :
      monMot.append(mot[i] + " ")
    else :
       monMot.append("_ ")
    i = i +1
  print("".join(monMot))


#------------------------base du jeu (pendu)------------------------>>>
def game():
  word = choix_mot(fic)
  affiche_mot(word, lettre_vrai)
  while verif_fin(word) :
    lettre = choix_lettre()
    if verif_lettre(lettre, word) == True:
      affiche_mot(word, lettre_vrai)
    else:
      show_pendu() 


#-------------------vérification du nombre d'éssais------------------------->>>
def verif_fin(word) :
  trouver = True
  for car in word:
    if car not in lettre_vrai:
      trouver = False


  if len(lettre_faux) == 10:
    print("Tu as perdu, dommage !!")
    return False
  elif trouver:
    print("Tu as gagné, BRAVO !!!")
    return False
  else:
    return True


#-----------------fonction consigne donné a l'utilisateur----------------------->>>
def choix_lettre() :
  letter = input("Choix de la lettre : ")
  while len(letter) != 1 or ord(letter) <= 65 and ord(letter) >= 90:
    letter = input("Choix de la lettre : ")
  return letter


#-------------------vérification de la lettre choisi------------------------>>>
def verif_lettre(lettre, word):
  if lettre in word:
    lettre_vrai.append(lettre)
    return True
  else : 
    lettre_faux.append(lettre) 
    return False


#-----------------programme principale---------------------------->>>
start = 0
while start != 2:
  start = int(input("Veux tu jouer au pendu ?\n oui : 1\n non : 2\n votre réponse : "))
  if start == 1:
    game()
  else:
    print("A bientôt ;)")



